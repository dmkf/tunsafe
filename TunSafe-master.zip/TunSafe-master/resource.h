//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TunSafe.rc
//
#define IDI_ICON0                       1
#define IDI_ICON1                       2
#define ID_STOP                         3
#define IDRAND                          3
#define IDCANCEL2                       3
#define ID_RESTART                      4
#define ID_START                        5
#define ID_EXIT                         6
#define ID_EDITCONF                     8
#define ID_MORE_BUTTON                  9
#define IDSETT_WEB_PAGE                 10
#define IDSETT_ABOUT                    11
#define IDSETT_KEYPAIR                  12
#define IDSETT_OPENSOURCE               13
#define IDSETT_BROWSE_FILES             14
#define IDSETT_OPEN_FILE                15
#define IDSETT_BLOCKINTERNET_OFF        16
#define IDSETT_BLOCKINTERNET_ROUTE      17
#define IDSETT_BLOCKINTERNET_FIREWALL   18
#define IDSETT_BLOCKINTERNET_BOTH       19
#define IDSETT_PREPOST                  20
#define IDSETT_SERVICE_OFF              21
#define IDSETT_SERVICE_FOREGROUND       22
#define IDSETT_SERVICE_BACKGROUND       23
#define IDSETT_SERVICE_CONNECT_AUTO     24
#define IDSETT_SERVICE_MINIMIZE_AUTO    25
#define IDSETT_BLOCKINTERNET_DISCONN    26
#define IDSETT_BLOCKINTERNET_ALLOWLOCAL 27
#define ID_BTN_KILLSWITCH               28
#define IDC_PAINTBOX                    30
#define IDC_GRAPHBOX                    31
#define IDC_ADVANCEDBOX                 32
#define IDC_RICHEDIT21                  33
#define IDC_PRIVATE_KEY                 34
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     105
#define IDD_DIALOG3                     106
#define IDR_MENU1                       107
#define IDD_DIALOG4                     107
#define IDC_STATUSBAR                   108
#define IDB_DOWNARROW                   108
#define IDC_PUBLIC_KEY                  109
#define IDC_TAB                         110
#define IDC_CODENOTACCEPTED             111
#define IDC_TWOFACTOREDIT               1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40030
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
