# Windows 7 DDK
DDK = "C:\\winddk\\7600.16385.1"
NSIS = "C:\\Program Files (x86)\\NSIS"
