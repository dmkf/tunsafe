# TunSafe
Source code of the TunSafe client.

This open sourced TunSafe code is AGPL-1.0 licensed. Do note that the repository contains BSD and OpenSSL licensed files, so if you want to release a version based off of this repository you need to take that into account.

To build on Windows, open TunSafe.sln and build, or run build.py.

To build on Linux, run build_linux.sh

To build on FreeBSD, run build_freebsd.sh

